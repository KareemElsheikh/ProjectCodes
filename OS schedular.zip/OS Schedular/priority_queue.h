#include "headers.h"

typedef struct priQ
{
  int capacity;
  int size;

  process **queue;
} priQ;

/***** UTILS *****/
int parent(int i)
{
  return (i - 1) / 2;
}

int left(int i)
{
  return 2 * i + 1;
}

int right(int i)
{
  return 2 * i + 2;
}

bool comparisonSJF(process *x, process *y)
{
  if (x->runtime < y->runtime)
  {
    return true;
  }
  return false;
}

// shortest remaining first
bool comparison(process *x, process *y)
{
  // printf("I am flag %d\n",SJFflag);
  if (SJFflag == 1)
  {
    if (x->remainingtime < y->remainingtime)
    {
      return true;
    }
    return false;
  }
  if (x->priority < y->priority)
  {
    return true;
  }
  return false;
}

void swap(process **x, process **y)
{
  process *temp = *x;
  *x = *y;
  *y = temp;
}

// 1 for success, 0 for failed (when no queue is passed)
bool priQcreate(priQ *all_process, int capacity)
{
  if (!all_process)
    return 0;
  if (!capacity)
    capacity = 50;

  all_process->size = 0;
  all_process->capacity = capacity;
  all_process->queue = (process **)calloc(all_process->capacity, sizeof(process *)); // initialize to zero
  return 1;
}

process *priQpeek(priQ *all_process)
{
  if (all_process->size == 0)
    return NULL;
  return all_process->queue[0];
}

void reheapDown(priQ *all_process, int i)
{
  int *size = &all_process->size;
  bool left_ok = left(i) < *size && comparison(all_process->queue[left(i)], all_process->queue[i]);
  bool right_ok = right(i) < *size && comparison(all_process->queue[right(i)], all_process->queue[i]);

  while (i < *size && (left_ok || right_ok))
  {
    if (left_ok && right_ok)
    {
      if (comparison(all_process->queue[left(i)], all_process->queue[right(i)]))
      {
        swap(&all_process->queue[i], &all_process->queue[left(i)]);
        i = left(i);
      }
      else
      {
        swap(&all_process->queue[i], &all_process->queue[right(i)]);
        i = right(i);
      }
    }
    else if (left_ok)
    {
      swap(&all_process->queue[i], &all_process->queue[left(i)]);
      i = left(i);
    }
    else
    {
      swap(&all_process->queue[i], &all_process->queue[right(i)]);
      i = right(i);
    }

    left_ok = left(i) < *size && comparison(all_process->queue[left(i)], all_process->queue[i]);
    right_ok = right(i) < *size && comparison(all_process->queue[right(i)], all_process->queue[i]);
  }
}

void reheapUp(priQ *all_process)
{
  int *size = &all_process->size;

  int i = *size - 1;
  while (i != 0 && comparison(all_process->queue[i], all_process->queue[parent(i)]))
  {
    swap(&all_process->queue[i], &all_process->queue[parent(i)]);
    i = parent(i);
  }
}

bool priQenqueue(priQ *all_process, process *p)
{
  if (all_process->capacity == all_process->size)
    return 0;
  int *size = &all_process->size;
  all_process->queue[*size] = p;
  (*size)++;
  // reheap up
  reheapUp(all_process);
  return 1;
}

bool priQremove(priQ *all_process, process *p)
{
  int i;
  int *size = &all_process->size;

  for (i = 0; i < *size; i++)
  {
    if (all_process->queue[i] == p)
    {
      swap(&all_process->queue[i], &all_process->queue[*size - 1]);
      (*size)--;
      reheapDown(all_process, i);
      // break;
      return 1;
    }
  }
  return 0;
}

bool priQfree(priQ *all_process)
{
  if (!all_process || !all_process->queue)
    return 0;
  free(all_process->queue);
  return 1;
}

// int main()
// {
//   priQ q;
//   priQcreate(&q, 20);
//   process process1;
//   process1.priority = 7;
//   priQenqueue(&q, &process1);

//   process process2;
//   process2.priority = 5;
//   priQenqueue(&q, &process2);

//   printf("p: %d \n", priQpeek(&q)->priority);
//   // priQremove(&q, &process2);
//   // priQfree(&q);
//   printf("p: %d \n", priQpeek(&q)->priority);

//   //     int A[tree_array_size];
//   //     insert(A, 20);
//   //     insert(A, 15);
//   //     insert(A, 8);
//   //     insert(A, 10);
//   //     insert(A, 5);
//   //     insert(A, 7);
//   //     insert(A, 6);
//   //     insert(A, 2);
//   //     insert(A, 9);
//   //     insert(A, 1);

//   //     print_heap(A);

//   //     printf("%d\n\n", minimum(A));
//   //     printf("%d\n\n", extract_min(A));

//   //     print_heap(A);

//   return 0;
// }
