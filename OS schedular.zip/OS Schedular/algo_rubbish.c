
// https : // stackoverflow.com/a/44102485
#include <stdio.h>

// each of theses is considered a child
typedef struct we object;
typedef struct we car;
typedef struct we hpf;

// we is considered the parent class
struct we
{
    float x, y;
    void *type;
    void (*setCoordinates)(object *self, float x, float y);
    float (*getYCoordinate)(object *self);
    float (*getXCoordinate)(object *self);
};

// implement the functions you want in each child class
void object_setCoordinates(object *self, float x, float y)
{
    self->x = x;
    self->y = y;
}

float object_getXCoordinate(object *self)
{
    return self->x;
}

float car_getYCoordinate(car *self)
{
    printf("welcome 7abiby");
    return self->y;
}

float object_getYCoordinate(object *self)
{
    return self->y;
}

int main()
{

    car point;
    // point.setCoordinates = object_setCoordinates;
    // point.getYCoordinate = car_getYCoordinate;
    // point.getXCoordinate = object_getXCoordinate;

    // point.setCoordinates(&point, 1, 2);
    // printf("Coordinates: X Coordinate: %f, Y Coordinate: %f",
    // point.getXCoordinate(&point), point.getYCoordinate(&point));
    car point2;
    object_setCoordinates(&point, 1, 2);
    printf("Y %f \n", object_getYCoordinate(&point));
}
// object x;
// object_setCoordinates(x, 1, 2);

// steps:
// 1. define the parent struct (we in this case), each function is a pionter
// 2. declare a type struct of this parent struct
// 4. implement the functions you want in each child class
// 5. declare a variable of the child struct
// 6. bind the functions to the